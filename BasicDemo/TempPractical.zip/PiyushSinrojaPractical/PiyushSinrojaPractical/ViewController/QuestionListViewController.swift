//
//  QuestionListViewController.swift
//  PiyushSinrojaPractical
//
//  Created by Admin on 05/11/20.
//  Copyright © 2020 Piyush. All rights reserved.
//

import UIKit

class QuestionListViewController: UIViewController {
   
    // MARK: - IBOutlet
    
    @IBOutlet weak var questionListTableView: UITableView!
   
    // MARK: - Variables
    var arrFirstNumber = [1,2,3,4,5,6,7,8,9]
    var arrSecondNumber = [1,2,3,4,5,6,7,8,9]
    var arrOperator: [String] = ["+", "-" , "*" , "/"]
    var resultDic = [Int: Int]()
    var finalDic = [Int: Int]()
    
    // MARK: - Lifecycle method
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            appDelegate.deviceOrientation = .landscape
            let value = UIInterfaceOrientation.landscapeRight.rawValue
            UIDevice.current.setValue(value, forKey: "orientation")
        }
    }
    
    /// button action from cell
    @objc func buttonActionFromCell(sender: UIButton) {
        guard let title = sender.title(for: .normal) else { return }
        let selec = resultDic[sender.tag] ?? 0
        if Int(title) == selec {
             self.showAlert(message: "Correct", buttonTitle: Messages.Button.okButton)
        }
    }
}

// MARK: - UITableViewDataSource
extension QuestionListViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 15
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "QuestionListTableViewCell") as? QuestionListTableViewCell else {
            fatalError("Cell not exists in storyboard")
        }
        guard let firstRandom = arrFirstNumber.randomElement(), let randomOper = arrOperator.randomElement(), let secondRandom = arrSecondNumber.randomElement() else {
            return cell
        }
        cell.questionNoLabel.text = "Q:\(indexPath.row + 1)"
        cell.questionLabel.text = "\(firstRandom) \(randomOper) \(secondRandom)"
        
        var answer = 0
        switch randomOper {
        case "*":
            answer = firstRandom * secondRandom
        case "/":
            answer = firstRandom / secondRandom
        case "-":
            answer = firstRandom - secondRandom
        case "+":
            answer = firstRandom + secondRandom
        default:
            break
        }
        var randomArr = [Int]()
        for index in 1...50 {
            randomArr.append(index)
        }
        var buttonArray = [cell.optionCButton, cell.optionBButton, cell.optionAButton, cell.optionDButton]
        for value in buttonArray {
             value?.addTarget(self, action: #selector(QuestionListViewController.buttonActionFromCell(sender:)), for: .touchUpInside)
             value?.tag = indexPath.row
        }
        
        guard let randomButton = buttonArray.randomElement() else {
            return cell
        }
        randomButton?.setTitle("\(answer)", for: .normal)
        if let index = buttonArray.firstIndex(where: { $0 == randomButton }) {
            buttonArray.remove(at: index)
        }
        buttonArray[0]?.setTitle("\(randomArr.randomElement() ?? 0)", for: .normal)
        buttonArray[1]?.setTitle("\(randomArr.randomElement() ?? 0)", for: .normal)
        buttonArray[2]?.setTitle("\(randomArr.randomElement() ?? 0)", for: .normal)
        resultDic[indexPath.row] = answer
        return cell
    }
}
// MARK: - UITableViewDelegate
extension QuestionListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.size.height
    }
}
