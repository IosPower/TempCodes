//
//  LoginViewController.swift
//  PiyushSinrojaPractical
//
//  Created by Admin on 05/11/20.
//  Copyright © 2020 Piyush. All rights reserved.
//

import UIKit
class LoginViewController: UIViewController {
    
    // MARK: - IBOutlets
    ///
    @IBOutlet weak var emailTextfield: UITextField!
    ///
    @IBOutlet weak var passwordTextfield: UITextField!
    ///
    @IBOutlet weak var submitButton: UIButton!
    
    // MARK: - Variables
    
    ///
    private var activeTextfield: UITextField?
    
    ///
    private var loginViewModel: LoginViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setupUI()
    }
    
    // MARK: - Initializing UI Methods
    
    ///
    func setupUI() {
        loginViewModel = LoginViewModel()
    }
    
    // MARK: - IBActions
    
    @IBAction func submitButtonAction(_ sender: Any) {
        loginViewModel?.email = emailTextfield.text ?? ""
        loginViewModel?.password = passwordTextfield.text ?? ""
      
        // check login validation and call login api
        loginViewModel?.validation { [weak self] (isValid, message) in
            guard isValid else {
                self?.showAlert(message: message, buttonTitle: Messages.Button.okButton, completion: {
                    self?.activeTextfield?.becomeFirstResponder()
                })
                return
            }
            self?.view.endEditing(true)
            self?.loginAPICall()
        }
    }
    
    // MARK: - API Methods
    
    /// callApi for login
    func loginAPICall() {
        
        self.loginViewModel?.loginApi(success: { [weak self] in
        //    navigation here
            guard let queVC = self?.storyboard?.instantiateViewController(identifier: "QuestionListViewController") as? QuestionListViewController else { return }
            self?.navigationController?.pushViewController(queVC, animated: true)
            }, failure: { [weak self] (responseDict) in
                if let message = responseDict[ModelKeys.ResponseKeys.message] as? String {
                    self?.showAlert(message: message, buttonTitle: Messages.Button.okButton)
                }
        })
    }
}
