//
//  RegisterViewController.swift
//  PiyushSinrojaPractical
//
//  Created by Admin on 05/11/20.
//  Copyright © 2020 Piyush. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {
    
    
    // MARK: - IBOutlets
    
    ///
    @IBOutlet weak var firstNameTextfield: UITextField!
    ///
    @IBOutlet weak var lastNameTextfield: UITextField!
    ///
    @IBOutlet weak var emailTextfield: UITextField!
    ///
    @IBOutlet weak var companyNameTextfield: UITextField!
    ///
    @IBOutlet weak var contactPersonTextfield: UITextField!
    ///
    @IBOutlet weak var phoneTextfield: UITextField!
    ///
    @IBOutlet weak var addressTextfield: UITextField!
    ///
    @IBOutlet weak var passwordTextfield: UITextField!
    ///
    @IBOutlet weak var submitButton: UIButton!
    
    // MARK: - Variables
    
    ///
    private var registerViewModel: RegisterViewModel?
    
    // MARK: - Lifecycle method
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    // MARK: - Initializing UI Methods
    
    /// setup method
    func setupUI() {
        registerViewModel = RegisterViewModel()
    }
    
    // MARK: - IBActions
    
    @IBAction func submitButtonAction(_ sender: Any) {
        guard let queVC = self.storyboard?.instantiateViewController(identifier: "QuestionListViewController") as? QuestionListViewController else { return }
        self.navigationController?.pushViewController(queVC, animated: true)
        
//        registerViewModel?.email = emailTextfield.text?.removeWhiteSpace() ?? ""
//        registerViewModel?.password = passwordTextfield.text?.removeWhiteSpace() ?? ""
//        
//        registerViewModel?.firstName = firstNameTextfield.text?.removeWhiteSpace() ?? ""
//        registerViewModel?.lastName = lastNameTextfield.text?.removeWhiteSpace() ?? ""
//        
//        registerViewModel?.address = addressTextfield.text?.removeWhiteSpace() ?? ""
//        registerViewModel?.company_name = companyNameTextfield.text?.removeWhiteSpace() ?? ""
//        
//        registerViewModel?.contact_person = contactPersonTextfield.text?.removeWhiteSpace() ?? ""
//        registerViewModel?.phone = phoneTextfield.text?.removeWhiteSpace() ?? ""
//        
//        
//        // check login validation and call login api
//        registerViewModel?.validation { [weak self] (isValid, message) in
//            guard isValid else {
//                self?.showAlert(message: message, buttonTitle: Messages.Button.okButton)
//                return
//            }
//            self?.view.endEditing(true)
//            self?.registerAPICall()
//        }
    }
    
    ///
    @IBAction func alredyRegisterButtonAction(_ sender: Any) {
        guard let loginVC = self.storyboard?.instantiateViewController(identifier: "LoginViewController") as? LoginViewController else { return }
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    
    
    // MARK: - API Methods
    
    /// callApi for login
    func registerAPICall() {
        self.registerViewModel?.registerApi(success: { [weak self] in
            guard let loginVC = self?.storyboard?.instantiateViewController(identifier: "LoginViewController") as? LoginViewController else { return }
            self?.navigationController?.pushViewController(loginVC, animated: true)
            }, failure: { [weak self] (responseDict) in
                if let message = responseDict[ModelKeys.ResponseKeys.message] as? String {
                    self?.showAlert(message: message, buttonTitle: Messages.Button.okButton)
                }
        })
    }
    
}
