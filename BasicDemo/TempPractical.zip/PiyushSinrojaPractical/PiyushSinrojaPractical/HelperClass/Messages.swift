//
//  Messages.swift
//  PiyushSinrojaPractical
//
//  Created by Admin on 05/11/20.
//  Copyright © 2020 Piyush. All rights reserved.
//
import Foundation

/// All the messages to be displayed in the app.
class Messages: NSObject {
    
    ///
    static let strReqTimeOut = "The request timed out, Please try again."
    ///
    static let internetAlertMsg = "Please check your internet connection."
    ///
    static let tryAgain: String = "Please try again."
    ///
    static let somethingWrong = "Something went wrong."
    ///
    static let appTitle = "PracticalTest"
    
    // MARK: - Button title strings
    ///
    struct Button {
        ///
        static let okButton = "OK"
        ///
        static let cancelButton = "Cancel"
        ///
        static let yesButton = "Yes"
        ///
        static let noButton = "No"
    }
    
    // MARK: - Login Screen Messages
    ///
    struct LoginScreen {
        ///
        static let strEmailAndPassValidMsg = "You must enter a valid email address and password."
        ///
        static let strEmailIdMsg = "Please enter an email address."
        ///
        static let strValidEmailIdMsg = "Please enter a valid email address."
        ///
        static let strpasswordMsg = "Please enter password."
        ///
        static let strValidpasswordMsg = "password must be at least 6 characters long."
        
        ///
        static let strFirstNameMsg = "Please enter firstname."
        ///
        static let strValidFirstNameMsg = "The first name must be at least 3 characters long."
        ///
        static let strLastNameMsg = "Please enter lastname."
        ///
        static let strValidLastNameMsg = "The last name must be at least 3 characters long."
        //
        static let strBirthDateMsg = "Please enter birth date."
        ///
        static let strAddressMsg = "Please enter address."
        ///
        static let strCompanyNameMsg = "Please enter company name."
        ///
        static let strContactPersonMsg = "Please enter contact person's name."
        ///
        static let strPhoneMsg = "Please enter phone no."
        ///
        static let strValidPhoneMsg = "Please enter valid phone no."
        
    }
}
