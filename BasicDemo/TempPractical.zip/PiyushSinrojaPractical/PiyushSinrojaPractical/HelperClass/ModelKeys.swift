//
//  ModelKeyEnums.swift
//  PiyushSinrojaPractical
//
//  Created by Admin on 05/11/20.
//  Copyright © 2020 Piyush. All rights reserved.
//
import UIKit

/// useful keys
struct ModelKeys {
    ///
    struct ApiHeaderKeys {
        static let contentType = "Accept"
        static let applicationOrJson = "application/json"
        static let multipartOrFormData = "multipart/form-data"
        static let token = "x-access-token"
    }
    
    /// response keys
    struct ResponseKeys {
        static let status = "status"
        static let data = "data"
        static let result = "result"
        static let message = "message"
    }
}
