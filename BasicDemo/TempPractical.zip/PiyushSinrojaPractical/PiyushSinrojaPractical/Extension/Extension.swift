//
//  Extension.swift
//  PiyushSinrojaPractical
//
//  Created by Admin on 05/11/20.
//  Copyright © 2020 Piyush. All rights reserved.
//
import UIKit
import MBProgressHUD

// MARK: - Extension for String Methods
///
extension String {
    /// Trim string from left & right side extra spaces.
    ///
    /// - Returns: final string after removing extra left & right space.
    
    ///
    func removeWhiteSpace() -> String {
        return self.trimmingCharacters(in: .whitespaces)
    }
    
    // check valid mail
    func isValidEmail() -> Bool {
        if self.isEmpty {
            return false
        }
        let emailRegEx = "[.0-9a-zA-Z_-]+@[0-9a-zA-Z.-]+\\.[a-zA-Z]{2,20}"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        if !emailTest.evaluate(with: self) {
            return false
        }
        return true
    }
    
    func isValidPhone() -> Bool {
        let phoneRegex = "^[0-9+]{0,1}+[0-9]{9,16}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        return phoneTest.evaluate(with: self)
    }
    
    // check valid Password
    func isValidPassword() -> Bool {
        let passwordRegex = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z!@#$£€§%…^&*\\/()\\[\\]\\-_=+{}|?>.<,:;~`'\"/\\\\]{8,128}$"
        return NSPredicate(format: "SELF MATCHES %@", passwordRegex).evaluate(with: self)
    }
    
    /// from base64 to string convertion
    func fromBase64() -> String? {
        guard let data = Data(base64Encoded: self) else {
            return nil
        }
        return String(data: data, encoding: .utf8)
    }
    /// string to base64 string
    func toBase64() -> String {
        return Data(self.utf8).base64EncodedString()
    }
    /// check string is numeric or not
    var isNumeric: Bool {
        guard self.count > 0 else { return false }
        let nums: Set<Character> = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
        return Set(self).isSubset(of: nums)
    }
}
// MARK: - UIButton Extension
extension UIButton {
    /// borderColor
    ///
    /// - Parameter borderColor: CGColor
    func borderColor(_ borderColor: CGColor) {
        layer.borderWidth = 1.0
        layer.borderColor = borderColor
    }
}

// MARK: UITextField Extension
///
extension UITextField {
    
    /// Place holder color.
    @IBInspectable var placeHolderColorJS: UIColor? {
        get {
            return self.placeHolderColorJS
        }
        set {
            guard let placehldr = self.placeholder else { return }
            self.attributedPlaceholder = NSAttributedString(string: self.placeholder != nil ? placehldr : "", attributes: [NSAttributedString.Key.foregroundColor: newValue ?? .lightGray])
        }
    }
}


// MARK: - Array Extension
///
extension Array where Iterator.Element == String {
    
    /// sorting string in ascending order
    ///
    /// - Returns: It will return array of sorted string.
    func sortedAscArrayOfString() -> [String] {
        let sortedArray = self.sorted { $0.localizedCaseInsensitiveCompare($1) == ComparisonResult.orderedAscending }
        return sortedArray
    }
}


extension Sequence where Element: Equatable {
    var uniqueElements: [Element] {
        return self.reduce(into: []) { uniqueElements, element in
            if !uniqueElements.contains(element) {
                uniqueElements.append(element)
            }
        }
    }
}

///
extension UIViewController {
    /// common alert controller
    func showAlert(_ title: String = Messages.appTitle, message: String, buttonTitle: String) {
        DispatchQueue.main.async { [unowned self] in
            let alert: UIAlertController = UIAlertController(title: title, message: message, preferredStyle: .alert )
            alert.addAction(UIAlertAction(title: buttonTitle, style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    /// common alert controller
    func showAlert(_ title: String = Messages.appTitle, message: String, buttonTitle: String, completion: @escaping () -> Void) {
        DispatchQueue.main.async { [unowned self] in
            let alert: UIAlertController = UIAlertController(title: title, message: message, preferredStyle: .alert )
            let okAction = UIAlertAction(title: buttonTitle, style: .default, handler: { (_) in
                completion()
            })
            alert.addAction(okAction)
            self.present(alert, animated: true, completion: nil)
        }
    }
}
