//
//  ApiList.swift
//  PiyushSinrojaPractical
//
//  Created by Admin on 05/11/20.
//  Copyright © 2020 Piyush. All rights reserved.
//

import UIKit

/// This struct contains all Api list
struct ApiList {
    ///
    static let loginApi = "login"
    ///
    static let registerApi = "register"
}
