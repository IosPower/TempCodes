//
//  RegisterViewModel.swift
//  PiyushSinrojaPractical
//
//  Created by Admin on 05/11/20.
//  Copyright © 2020 Piyush. All rights reserved.
//

import SwiftyJSON

class RegisterViewModel {
    
    // MARK: - Variables
    
    ///
    var firstName: String = ""
    ///
    var lastName: String = ""
    ///
    var email: String = ""
    ///
    var password: String = ""
    ///
    var is_term_accept = 1
    ///
    var role = 3
    ///
    var dob: String = ""
    ///
    var gender = 1
    ///
    var address: String = ""
    ///
    var address_lat: String = "23.0225"
    ///
    var address_long: String = "72.571"
    ///
    var company_name: String = ""
    ///
    var contact_person: String = ""
    ///
    var phone: String = ""
    ///
    var category = 1
    ///
    var referral_code = 1234
    ///
    var instagram_client_id = 1234
    ///
    var tripadvisor_client_id = 1234
    
    /// This is login model
    //var loginModel: LoginModel!
    
    // MARK: - API Call
    
    func  registerApi(success: @escaping () -> Void, failure: @escaping (_ errorResponse: [String: Any]) -> Void) {
        let param: [String: Any] = ["email": email,
                                    "password": password,
                                    "first_name": firstName,
                                    "last_name": lastName,
                                    "is_term_accept": is_term_accept,
                                    "role": role,
                                    "dob": dob,
                                    "gender": gender,
                                    "address": address,
                                    "address_lat": address_lat,
                                    "address_long": address_long,
                                    "company_name": company_name,
                                    "contact_person": contact_person,
                                    "phone": phone,
                                    "category": category,
                                    "referral_code": referral_code,
                                    "instagram_client_id": instagram_client_id,
                                    "tripadvisor_client_id": tripadvisor_client_id]
        
        ApiManager.sharedInstance.multipartRequest(parameter: param, images: nil, imageKeysArray: [], urlPath: ApiList.registerApi, httpMethod: .post, success: { [weak self] (response) in
            let jsonData = JSON(response)
            let data = jsonData[ModelKeys.ResponseKeys.data].dictionaryValue
            if data[ModelKeys.ResponseKeys.status] == 200 {
                print(jsonData)
                // bind model here
                DispatchQueue.main.async {
                    success()
                }
            } else {
                var errorMessage = Messages.somethingWrong
                if let message = data[ModelKeys.ResponseKeys.message]?.string {
                    errorMessage = message
                }
                failure([ModelKeys.ResponseKeys.message: errorMessage])
            }
            
            }, failure: { (error) in
                let errorRes: [String: Any] = ["message": error?.localizedDescription ?? ""]
                failure(errorRes)
        })
    }
    
    // MARK: - Validation Login
    
    ///
    /// Validation for login
    ///
    /// - Parameter completion: completion return with bool and message string
    func validation(completion: @escaping (Bool, String) -> Void) {
        if firstName.removeWhiteSpace().isEmpty {
            completion (false, Messages.LoginScreen.strFirstNameMsg)
        } else if firstName.removeWhiteSpace().count < 3 {
            completion (false, Messages.LoginScreen.strValidFirstNameMsg)
        } else if lastName.removeWhiteSpace().isEmpty {
            completion (false, Messages.LoginScreen.strLastNameMsg)
        } else if lastName.removeWhiteSpace().count < 3 {
            completion (false, Messages.LoginScreen.strValidLastNameMsg)
        } else if email.removeWhiteSpace().isEmpty {
            completion (false, Messages.LoginScreen.strEmailIdMsg)
        } else if email.isValidEmail() == false {
            completion (false, Messages.LoginScreen.strValidEmailIdMsg)
        } else if company_name.removeWhiteSpace().isEmpty {
            completion (false, Messages.LoginScreen.strCompanyNameMsg)
        } else if contact_person.removeWhiteSpace().isEmpty {
            completion (false, Messages.LoginScreen.strContactPersonMsg)
        } else if phone.removeWhiteSpace().isEmpty {
            completion (false, Messages.LoginScreen.strPhoneMsg)
        } else if phone.isValidPhone() == false {
            completion (false, Messages.LoginScreen.strValidPhoneMsg)
        } else if address.removeWhiteSpace().isEmpty {
            completion (false, Messages.LoginScreen.strAddressMsg)
        } else if password.removeWhiteSpace().isEmpty {
            completion (false, Messages.LoginScreen.strpasswordMsg)
        } else if password.removeWhiteSpace().count < 3 {
            completion (false, Messages.LoginScreen.strValidpasswordMsg)
        } else {
            completion (true, "")
        }
    }
}
