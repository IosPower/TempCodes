//
//  QuestionListTableViewCell.swift
//  PiyushSinrojaPractical
//
//  Created by Admin on 05/11/20.
//  Copyright © 2020 Piyush. All rights reserved.
//

import UIKit

class QuestionListTableViewCell: UITableViewCell {

    ///
    @IBOutlet weak var questionNoLabel: UILabel!
    ///
    @IBOutlet weak var questionLabel: UILabel!
    ///
    @IBOutlet weak var optionAButton: UIButton!
    ///
    @IBOutlet weak var optionBButton: UIButton!
    ///
    @IBOutlet weak var optionCButton: UIButton!
    ///
    @IBOutlet weak var optionDButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
